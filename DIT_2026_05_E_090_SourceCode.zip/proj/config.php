<?php
session_start();   // needed for login

// Database connection (default XAMPP settings: user root, no password)
$host = "localhost"; $dbname = "student_accommodation"; $user = "root"; $pass = "";
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed. Is MySQL running and database.sql imported?");
}

// Safe output helper: stops HTML/script injection (XSS)
function e($text) { return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8'); }

// Logged-in student (or null)
function current_user() { return $_SESSION['user'] ?? null; }

// Send visitors to the login page if they are not logged in
function require_login() {
    if (!current_user()) {
        header('Location: login.php?next=' . urlencode(basename($_SERVER['REQUEST_URI'])));
        exit;
    }
}

// Photos for one accommodation: images/accommodations/<id>-1.jpg, <id>-2.jpg ...
function acc_images($id) {
    $files = glob(__DIR__ . '/images/accommodations/' . (int)$id . '-*.*');
    sort($files);
    $list = array_map(fn($f) => 'images/accommodations/' . basename($f), $files);
    return $list ?: ['images/student-accommodation.avif'];   // default photo if none added
}

function gender_label($g) { return ['boys'=>'Boys only','girls'=>'Girls only','mixed'=>'Mixed'][$g] ?? $g; }

// Rating text, e.g. "4.5 / 5 (2 reviews)"
function rating_text($avg, $count) {
    return $count ? '⭐ ' . $avg . ' / 5 (' . $count . ' review' . ($count > 1 ? 's' : '') . ')' : 'No ratings yet';
}

// Accommodation list query with the average rating worked out from the reviews table
const ACC_SQL = "SELECT a.*, ROUND(AVG(r.rating),1) AS avg_rating, COUNT(r.id) AS review_count
                 FROM accommodations a LEFT JOIN reviews r ON r.accommodation_id = a.id";
