<?php
require 'config.php';
$errors = []; $name = $email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? ''); $email = trim($_POST['email'] ?? '');
    $pw = $_POST['password'] ?? ''; $pw2 = $_POST['password2'] ?? '';
    if ($name === '') $errors[] = 'Please enter your name.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid email address.';
    if (strlen($pw) < 8) $errors[] = 'Password must be at least 8 characters.';
    if ($pw !== $pw2) $errors[] = 'The two passwords do not match.';
    if (!$errors) {
        $chk = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $chk->execute([$email]);
        if ($chk->fetch()) { $errors[] = 'This email is already registered. Please log in.'; }
        else {
            // password_hash() stores a scrambled version, never the real password
            $pdo->prepare("INSERT INTO users (name, email, password_hash) VALUES (?,?,?)")
                ->execute([$name, $email, password_hash($pw, PASSWORD_DEFAULT)]);
            session_regenerate_id(true);
            $_SESSION['user'] = ['id' => (int)$pdo->lastInsertId(), 'name' => $name];
            header('Location: index.php'); exit;
        }
    }
}
$title = 'Register';
include 'includes/header.php';
?>
<section class="section narrow">
    <h1>Student registration</h1>
    <?php if ($errors): ?><div class="alert bad" role="alert"><ul><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
    <form method="post" id="register-form" novalidate>
        <label for="name">Full name</label><input id="name" name="name" value="<?= e($name) ?>" required autocomplete="name">
        <label for="email">Email address</label><input id="email" name="email" type="email" value="<?= e($email) ?>" required autocomplete="email">
        <label for="password">Password (at least 8 characters)</label><input id="password" name="password" type="password" required autocomplete="new-password">
        <label for="password2">Confirm password</label><input id="password2" name="password2" type="password" required autocomplete="new-password">
        <button class="btn" type="submit">Create account</button>
    </form>
    <p>Already registered? <a href="login.php">Log in</a></p>
</section>
<?php include 'includes/footer.php'; ?>
