<?php
require 'config.php';
$title = 'Find Accommodation';
$all = $pdo->query(ACC_SQL . " GROUP BY a.id ORDER BY a.name")->fetchAll(PDO::FETCH_ASSOC);
include 'includes/header.php';
?>
<section class="page-header"><h1>Find Accommodation</h1><p>Search for suitable student accommodation near your university.</p></section>

<section class="section">
    <h2>Search</h2>
    <!-- Filters work instantly with JavaScript (js/main.js) -->
    <div class="search-form">
        <div class="form-group wide"><label for="f-keyword">Search by name or area</label>
            <input id="f-keyword" type="search" placeholder="e.g. Green View or Nugegoda"></div>
        <div class="form-group"><label for="f-university">University</label>
            <select id="f-university">
                <option value="">Any university</option>
                <option value="USJ">University of Sri Jayewardenepura</option>
                <option value="UOC">University of Colombo</option>
                <option value="UOM">University of Moratuwa</option>
                <option value="KDU">Kotelawala Defence University</option>
            </select></div>
        <div class="form-group"><label for="f-location">Location</label>
            <select id="f-location">
                <option value="">Any location</option>
                <option>Nugegoda</option><option>Maharagama</option><option>Dehiwala</option>
                <option>Kottawa</option><option>Homagama</option><option>Piliyandala</option>
                <option>Moratuwa</option><option>Rajagiriya</option>
            </select></div>
        <div class="form-group"><label for="f-price">Maximum monthly price</label>
            <select id="f-price">
                <option value="">Any price</option>
                <option value="10000">Up to Rs. 10,000</option><option value="15000">Up to Rs. 15,000</option>
                <option value="20000">Up to Rs. 20,000</option><option value="25000">Up to Rs. 25,000</option>
            </select></div>
        <div class="form-group"><label for="f-room">Room type</label>
            <select id="f-room">
                <option value="">Any room type</option><option value="single">Single room</option><option value="shared">Shared room</option>
            </select></div>
        <div class="form-group"><label for="f-gender">Boys / Girls</label>
            <select id="f-gender">
                <option value="">Any</option><option value="boys">Boys only</option><option value="girls">Girls only</option><option value="mixed">Mixed</option>
            </select></div>
        <div class="form-group"><label for="f-distance">Distance to university</label>
            <select id="f-distance">
                <option value="">Any distance</option><option value="1">Within 1 km</option><option value="3">Within 3 km</option><option value="5">Within 5 km</option>
            </select></div>
        <div class="form-group"><label for="f-sort">Sort by</label>
            <select id="f-sort">
                <option value="name">Name</option><option value="price-asc">Price: low to high</option>
                <option value="price-desc">Price: high to low</option><option value="rating">Best rated</option>
                <option value="distance">Nearest first</option>
            </select></div>
        <fieldset class="wide">
            <legend>Facilities</legend>
            <label class="check"><input type="checkbox" class="f-fac" value="wi-fi"> Wi-Fi</label>
            <label class="check"><input type="checkbox" class="f-fac" value="meals"> Meals</label>
            <label class="check"><input type="checkbox" class="f-fac" value="air conditioning"> Air conditioning</label>
            <label class="check"><input type="checkbox" class="f-fac" value="security"> Security</label>
            <label class="check"><input type="checkbox" class="f-fac" value="laundry"> Laundry</label>
            <label class="check"><input type="checkbox" id="f-available"> Available rooms only</label>
        </fieldset>
        <button id="reset-filters" class="btn secondary" type="button">Clear filters</button>
    </div>

    <p id="result-count" aria-live="polite"></p>
    <div class="grid" id="results">
        <?php foreach ($all as $a): ?><?php include 'includes/card.php'; ?><?php endforeach; ?>
    </div>
    <p id="no-results" hidden>No accommodation matches your search. Try changing the filters.</p>
</section>
<?php include 'includes/footer.php'; ?>
