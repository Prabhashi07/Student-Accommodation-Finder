<?php $title = 'How It Works'; require 'config.php'; include 'includes/header.php'; ?>
<section class="page-header"><h1>How It Works</h1><p>Five simple steps from searching to moving in.</p></section>
<section class="section">
    <ol class="steps">
        <li><strong>Register.</strong> Create a free student account (needed to book and to rate).</li>
        <li><strong>Search.</strong> Choose your university, location, budget, room type and facilities.</li>
        <li><strong>Compare.</strong> Open an accommodation to see photos, facilities, availability and student reviews.</li>
        <li><strong>Request.</strong> Send a booking request. You can follow it under My Bookings.</li>
        <li><strong>Rate.</strong> After your stay, rate the place so other students can choose well.</li>
    </ol>
    <a class="btn" href="find.php">Start searching</a>
</section>
<?php include 'includes/footer.php'; ?>
