<?php
session_start();
session_destroy();   // log the student out
header('Location: index.php');
