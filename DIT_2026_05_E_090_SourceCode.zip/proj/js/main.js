// ---------- 1. Mobile menu ----------
const toggle = document.getElementById('menu-toggle');
const links = document.getElementById('nav-links');
toggle.addEventListener('click', () => {
    const open = links.classList.toggle('open');
    toggle.setAttribute('aria-expanded', open);
});

// ---------- 2. Live search, filter and sort (find.php) ----------
const results = document.getElementById('results');
if (results) {
    const cards = Array.from(results.querySelectorAll('.card'));
    const $ = id => document.getElementById(id);
    const inputs = ['f-keyword','f-university','f-location','f-price','f-room','f-gender','f-distance','f-sort'].map($);
    const facBoxes = Array.from(document.querySelectorAll('.f-fac'));
    const available = $('f-available');

    function update() {
        const wanted = facBoxes.filter(b => b.checked).map(b => b.value);
        let shown = 0;
        cards.forEach(card => {
            const d = card.dataset;
            const ok =
                (!$('f-keyword').value || d.name.includes($('f-keyword').value.toLowerCase().trim())) &&
                (!$('f-university').value || d.university === $('f-university').value) &&
                (!$('f-location').value || d.location === $('f-location').value) &&
                (!$('f-price').value || Number(d.price) <= Number($('f-price').value)) &&
                (!$('f-room').value || d.room === $('f-room').value) &&
                (!$('f-gender').value || d.gender === $('f-gender').value) &&
                (!$('f-distance').value || Number(d.distance) <= Number($('f-distance').value)) &&
                wanted.every(w => d.facilities.includes(w)) &&
                (!available.checked || Number(d.available) > 0);
            card.hidden = !ok;
            if (ok) shown++;
        });
        // sorting: reorder the cards on the page
        const sorters = {
            'name': (a, b) => a.dataset.name.localeCompare(b.dataset.name),
            'price-asc': (a, b) => a.dataset.price - b.dataset.price,
            'price-desc': (a, b) => b.dataset.price - a.dataset.price,
            'rating': (a, b) => b.dataset.rating - a.dataset.rating,
            'distance': (a, b) => a.dataset.distance - b.dataset.distance
        };
        cards.sort(sorters[$('f-sort').value]).forEach(c => results.appendChild(c));
        $('result-count').textContent = shown + ' accommodation(s) found';
        $('no-results').hidden = shown !== 0;
    }
    inputs.forEach(i => i.addEventListener('input', update));
    facBoxes.forEach(b => b.addEventListener('change', update));
    available.addEventListener('change', update);
    $('reset-filters').addEventListener('click', () => {
        inputs.forEach(i => i.value = '');
        $('f-sort').value = 'name';
        facBoxes.forEach(b => b.checked = false);
        available.checked = false;
        update();
    });
    update();
}

// ---------- 3. Form validation (booking and register) ----------
function showErrors(form, problems) {
    let box = document.getElementById('js-errors');
    if (!box) { box = document.createElement('div'); box.id = 'js-errors'; box.className = 'alert bad'; box.setAttribute('role', 'alert'); form.before(box); }
    box.innerHTML = '<ul>' + problems.map(p => '<li>' + p + '</li>').join('') + '</ul>';
    box.scrollIntoView({behavior: 'smooth'});
}
const booking = document.getElementById('booking-form');
if (booking) {
    booking.move_in_date.min = new Date().toISOString().split('T')[0];   // no past dates
    booking.addEventListener('submit', event => {
        const problems = [];
        if (!/^[0-9+ ]{9,15}$/.test(booking.phone.value)) problems.push('Please enter a valid phone number.');
        if (!booking.move_in_date.value) problems.push('Please choose a move-in date.');
        if (problems.length) { event.preventDefault(); showErrors(booking, problems); }
    });
}
const register = document.getElementById('register-form');
if (register) {
    register.addEventListener('submit', event => {
        const problems = [];
        if (!register.name.value.trim()) problems.push('Please enter your name.');
        if (!/^\S+@\S+\.\S+$/.test(register.email.value)) problems.push('Please enter a valid email address.');
        if (register.password.value.length < 8) problems.push('Password must be at least 8 characters.');
        if (register.password.value !== register.password2.value) problems.push('The two passwords do not match.');
        if (problems.length) { event.preventDefault(); showErrors(register, problems); }
    });
}
