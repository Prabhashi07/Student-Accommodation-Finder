<?php
require 'config.php';
$title = 'Home';
// The 3 best rated places (average of student reviews)
$featured = $pdo->query(ACC_SQL . " GROUP BY a.id ORDER BY avg_rating DESC, a.id LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);
include 'includes/header.php';
?>
<section class="hero">
    <h1>Find Your Perfect Student Accommodation</h1>
    <p>Find comfortable, affordable and convenient places to stay near your university.</p>
    <a class="btn" href="find.php">Find Accommodation</a>
</section>

<section class="section">
    <h2>Top rated accommodation</h2>
    <div class="grid">
        <?php foreach ($featured as $a): ?><?php include 'includes/card.php'; ?><?php endforeach; ?>
    </div>
</section>

<section class="benefits">
    <img src="images/student-accommodation.avif" alt="Bedroom with a desk in a student boarding house">
    <div>
        <h2>Everything You Need in One Place</h2>
        <div class="benefit-item"><h3>📍 Find nearby accommodation</h3><p>Search by university and location.</p></div>
        <div class="benefit-item"><h3>💰 Compare prices</h3><p>Filter by monthly budget and room type.</p></div>
        <div class="benefit-item"><h3>🏠 Check facilities</h3><p>See Wi-Fi, meals and more before you visit.</p></div>
        <div class="benefit-item"><h3>⭐ Read real reviews</h3><p>Ratings come from registered students.</p></div>
        <p><a class="btn secondary" href="how-it-works.php">See how it works</a></p>
    </div>
</section>
<?php include 'includes/footer.php'; ?>
