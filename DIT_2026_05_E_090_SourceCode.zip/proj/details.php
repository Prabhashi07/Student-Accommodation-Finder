<?php
require 'config.php';
$id = (int)($_GET['id'] ?? $_POST['accommodation_id'] ?? 0);
$stmt = $pdo->prepare(ACC_SQL . " WHERE a.id = ? GROUP BY a.id");   // prepared statement = safe from SQL injection
$stmt->execute([$id]);
$a = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$a) { http_response_code(404); $title = 'Not found'; include 'includes/header.php';
    echo '<section class="section"><h1>Accommodation not found</h1><a class="btn" href="find.php">Back to search</a></section>';
    include 'includes/footer.php'; exit; }

$me = current_user();
$reviewError = '';

// A logged-in student sends or updates a rating
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $me) {
    $rating = (int)($_POST['rating'] ?? 0);
    $comment = trim($_POST['comment'] ?? '');
    if ($rating < 1 || $rating > 5) { $reviewError = 'Please choose a rating from 1 to 5.'; }
    elseif (strlen($comment) > 500) { $reviewError = 'Comment must be 500 characters or less.'; }
    else {
        $pdo->prepare("INSERT INTO reviews (accommodation_id, user_id, rating, comment) VALUES (?,?,?,?)
                       ON DUPLICATE KEY UPDATE rating = VALUES(rating), comment = VALUES(comment)")
            ->execute([$id, $me['id'], $rating, $comment]);
        header("Location: details.php?id=$id&rated=1#reviews"); exit;
    }
}

$reviews = $pdo->prepare("SELECT r.*, u.name FROM reviews r JOIN users u ON u.id = r.user_id WHERE r.accommodation_id = ? ORDER BY r.created_at DESC");
$reviews->execute([$id]);
$reviews = $reviews->fetchAll(PDO::FETCH_ASSOC);
$imgs = acc_images($id);
$title = $a['name'];
include 'includes/header.php';
?>
<section class="details">
    <div class="gallery">
        <img class="main-photo" src="<?= e($imgs[0]) ?>" alt="<?= e($a['name']) ?> main photo">
        <?php if (count($imgs) > 1): ?>
        <div class="thumbs"><?php foreach (array_slice($imgs, 1) as $n => $img): ?>
            <img src="<?= e($img) ?>" alt="<?= e($a['name']) ?> photo <?= $n + 2 ?>"><?php endforeach; ?></div>
        <?php endif; ?>
    </div>
    <div>
        <h1><?= e($a['name']) ?></h1>
        <p><strong>Location:</strong> <?= e($a['location']) ?> (<?= e($a['distance_km']) ?> km from university)</p>
        <p><strong>Monthly price:</strong> Rs. <?= number_format($a['price']) ?></p>
        <p><strong>Room type:</strong> <?= ucfirst(e($a['room_type'])) ?> room · <?= e(gender_label($a['gender'])) ?></p>
        <p><strong>Capacity:</strong> <?= (int)$a['capacity'] ?> student(s) per room</p>
        <p><strong>Rating:</strong> <?= e(rating_text($a['avg_rating'], $a['review_count'])) ?></p>
        <p><strong>Availability:</strong> <?= $a['rooms_available'] > 0 ? (int)$a['rooms_available'] . ' room(s) available' : 'Currently full' ?></p>
        <h2>Facilities</h2>
        <ul><?php foreach (explode(',', $a['facilities']) as $f): ?><li><?= e(trim($f)) ?></li><?php endforeach; ?></ul>
        <h2>About the accommodation</h2>
        <p><?= e($a['description']) ?></p>
        <?php if ($a['rooms_available'] > 0): ?>
            <a class="btn" href="booking.php?id=<?= (int)$a['id'] ?>">Send booking request</a>
        <?php endif; ?>
    </div>
</section>

<section class="section narrow" id="reviews">
    <h2>Student reviews</h2>
    <?php if (isset($_GET['rated'])): ?><div class="alert ok" role="status">Thank you! Your rating was saved.</div><?php endif; ?>
    <?php foreach ($reviews as $r): ?>
        <div class="review"><h3>⭐ <?= (int)$r['rating'] ?> / 5 <small>by <?= e($r['name']) ?></small></h3>
        <p><?= e($r['comment']) ?></p></div>
    <?php endforeach; ?>
    <?php if (!$reviews): ?><p>No reviews yet. Be the first to rate this place.</p><?php endif; ?>

    <h2>Rate this accommodation</h2>
    <?php if ($me): ?>
        <?php if ($reviewError): ?><div class="alert bad" role="alert"><?= e($reviewError) ?></div><?php endif; ?>
        <form method="post">
            <input type="hidden" name="accommodation_id" value="<?= (int)$id ?>">
            <label for="rating">Your rating</label>
            <select id="rating" name="rating" required>
                <option value="">Choose...</option>
                <?php for ($i = 5; $i >= 1; $i--): ?><option value="<?= $i ?>"><?= $i ?> star<?= $i > 1 ? 's' : '' ?></option><?php endfor; ?>
            </select>
            <label for="comment">Comment (optional)</label>
            <textarea id="comment" name="comment" rows="3" maxlength="500"></textarea>
            <button class="btn" type="submit">Submit rating</button>
        </form>
    <?php else: ?>
        <p>Only registered students can rate. <a href="login.php?next=details.php?id=<?= (int)$id ?>">Log in</a> or <a href="register.php">register</a>.</p>
    <?php endif; ?>
</section>
<?php include 'includes/footer.php'; ?>
