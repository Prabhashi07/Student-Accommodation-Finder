Student Accommodation Finder - setup (XAMPP)
1. Start Apache and MySQL in XAMPP.
2. Copy this folder into C:\xampp\htdocs\
3. http://localhost/phpmyadmin -> Import -> database.sql -> Go
4. Open http://localhost/proj/   (use your folder name)
Pages: index, find, details, booking, my-bookings, how-it-works, register, login, logout
Photos: images/accommodations/ (see README there)
