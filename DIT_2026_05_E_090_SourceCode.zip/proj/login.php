<?php
require 'config.php';
$error = ''; $email = '';
$next = $_GET['next'] ?? $_POST['next'] ?? 'index.php';
if (!preg_match('/^[a-z-]+\.php(\?id=\d+)?$/', $next)) $next = 'index.php';   // only allow our own pages

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($u && password_verify($_POST['password'] ?? '', $u['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => (int)$u['id'], 'name' => $u['name']];
        header('Location: ' . $next); exit;
    }
    $error = 'Wrong email or password.';
}
$title = 'Login';
include 'includes/header.php';
?>
<section class="section narrow">
    <h1>Student login</h1>
    <?php if ($error): ?><div class="alert bad" role="alert"><?= e($error) ?></div><?php endif; ?>
    <form method="post">
        <input type="hidden" name="next" value="<?= e($next) ?>">
        <label for="email">Email address</label><input id="email" name="email" type="email" value="<?= e($email) ?>" required autocomplete="email">
        <label for="password">Password</label><input id="password" name="password" type="password" required autocomplete="current-password">
        <button class="btn" type="submit">Log in</button>
    </form>
    <p>New here? <a href="register.php">Create an account</a></p>
</section>
<?php include 'includes/footer.php'; ?>
