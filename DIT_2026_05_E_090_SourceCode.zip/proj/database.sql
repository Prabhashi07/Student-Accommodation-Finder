-- Student Accommodation Finder database (import in phpMyAdmin)
CREATE DATABASE IF NOT EXISTS student_accommodation CHARACTER SET utf8mb4;
USE student_accommodation;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS accommodations;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,      -- never store plain passwords
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE accommodations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  university VARCHAR(10) NOT NULL,          -- USJ, UOC, KDU, UOM
  location VARCHAR(50) NOT NULL,
  distance_km DECIMAL(3,1) NOT NULL,        -- distance to the university
  price INT NOT NULL,                       -- monthly price in Rs.
  room_type VARCHAR(10) NOT NULL,           -- single or shared
  gender VARCHAR(10) NOT NULL,              -- boys, girls or mixed
  capacity INT NOT NULL,
  rooms_available INT NOT NULL,
  facilities VARCHAR(255) NOT NULL,
  description TEXT NOT NULL
);

CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  accommodation_id INT NOT NULL,
  user_id INT NOT NULL,
  phone VARCHAR(20) NOT NULL,
  move_in_date DATE NOT NULL,
  message TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (accommodation_id) REFERENCES accommodations(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  accommodation_id INT NOT NULL,
  user_id INT NOT NULL,
  rating TINYINT NOT NULL,                  -- 1 to 5
  comment VARCHAR(500),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY one_review_per_student (accommodation_id, user_id),
  FOREIGN KEY (accommodation_id) REFERENCES accommodations(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Demo students (these accounts cannot log in; they only own the sample reviews)
INSERT INTO users (name,email,password_hash) VALUES
('Kasun P.','demo1@example.com','DEMO-NO-LOGIN'),
('Nethmi S.','demo2@example.com','DEMO-NO-LOGIN'),
('Ravindu D.','demo3@example.com','DEMO-NO-LOGIN');

INSERT INTO accommodations (name,university,location,distance_km,price,room_type,gender,capacity,rooms_available,facilities,description) VALUES
('Green View Boarding','USJ','Nugegoda',1.2,15000,'shared','boys',2,3,'Wi-Fi, Meals, Study desk, Hot water','A comfortable boarding house a short walk from the university. Quiet street and friendly owners, ideal for students on a budget.'),
('Campus Comfort House','USJ','Maharagama',4.5,12000,'single','girls',1,2,'Wi-Fi, Study desk, Laundry area, Security','Private single rooms for girls with a shared kitchen. Ten minutes by bus from the university.'),
('Student Haven','UOC','Dehiwala',3.0,18000,'shared','mixed',2,4,'Wi-Fi, Meals, Air conditioning, Security','Modern shared rooms with air conditioning and 24-hour security, close to the railway station.'),
('Scholar Nest','KDU','Piliyandala',6.0,9500,'shared','boys',3,5,'Wi-Fi, Study desk','Affordable shared rooms for three students, with a common study area.'),
('Lakeside Residency','USJ','Kottawa',5.2,22000,'single','mixed',1,1,'Wi-Fi, Meals, Air conditioning, Gym, Hot water','Premium single rooms with an attached bathroom and meals included.'),
('Unity Student Lodge','KDU','Homagama',2.5,13500,'single','girls',1,2,'Wi-Fi, Laundry area, Security','Safe single rooms for girls in a quiet area. Regular buses to the campus.'),
('Moratuwa Scholars Inn','UOM','Moratuwa',0.8,16500,'shared','boys',2,3,'Wi-Fi, Study desk, Meals, Hot water','Walking distance to the university gate. Popular with engineering students.'),
('Rajagiriya Student Place','UOC','Rajagiriya',7.5,20000,'single','mixed',1,0,'Wi-Fi, Air conditioning, Security, Gym','Stylish single rooms near the main road. Currently full.');

INSERT INTO reviews (accommodation_id,user_id,rating,comment) VALUES
(1,1,5,'The location is convenient and the room is comfortable.'),
(1,2,4,'Good accommodation for students and reasonably priced.'),
(2,2,4,'Safe and quiet, the owner is very helpful.'),
(3,1,5,'Air conditioning and security make it worth the price.'),
(3,3,4,'Clean rooms and close to the station.'),
(4,3,4,'Cheap and clean. Bus to campus takes a while.'),
(5,2,5,'Best place I have stayed. Meals are great.'),
(6,1,4,'Peaceful area and friendly staff.'),
(7,3,5,'Two minutes to the university. Very convenient.'),
(7,1,4,'Rooms are small but the location is perfect.'),
(8,2,4,'Nice rooms, but a long ride to campus.');
