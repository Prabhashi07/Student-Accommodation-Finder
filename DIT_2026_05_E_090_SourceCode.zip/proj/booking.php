<?php
require 'config.php';
require_login();   // only logged-in students can book
$me = current_user();
$id = (int)($_GET['id'] ?? $_POST['accommodation_id'] ?? 0);
$stmt = $pdo->prepare("SELECT id, name, rooms_available FROM accommodations WHERE id = ?");
$stmt->execute([$id]);
$a = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$a || $a['rooms_available'] < 1) { header('Location: find.php'); exit; }

$errors = []; $success = false; $phone = $date = $message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = trim($_POST['phone'] ?? '');
    $date = $_POST['move_in_date'] ?? '';
    $message = trim($_POST['message'] ?? '');
    // Server-side validation (never trust only the browser)
    if (!preg_match('/^[0-9+ ]{9,15}$/', $phone)) $errors[] = 'Please enter a valid phone number.';
    if ($date === '' || $date < date('Y-m-d')) $errors[] = 'Please choose a move-in date that is today or later.';
    if (!$errors) {
        $pdo->prepare("INSERT INTO bookings (accommodation_id, user_id, phone, move_in_date, message) VALUES (?,?,?,?,?)")
            ->execute([$id, $me['id'], $phone, $date, $message]);
        $success = true;
    }
}
$title = 'Booking Request';
include 'includes/header.php';
?>
<section class="section narrow">
    <h1>Booking request</h1>
    <p>Accommodation: <strong><?= e($a['name']) ?></strong><br>Student: <strong><?= e($me['name']) ?></strong></p>
    <?php if ($success): ?>
        <div class="alert ok" role="status">Thank you! Your booking request was sent. The owner will contact you soon.</div>
        <a class="btn" href="my-bookings.php">View my bookings</a>
    <?php else: ?>
        <?php if ($errors): ?><div class="alert bad" role="alert"><ul><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <form method="post" id="booking-form" novalidate>
            <input type="hidden" name="accommodation_id" value="<?= (int)$a['id'] ?>">
            <label for="phone">Phone number</label>
            <input id="phone" name="phone" type="tel" value="<?= e($phone) ?>" required>
            <label for="move_in_date">Move-in date</label>
            <input id="move_in_date" name="move_in_date" type="date" value="<?= e($date) ?>" required>
            <label for="message">Message (optional)</label>
            <textarea id="message" name="message" rows="4"><?= e($message) ?></textarea>
            <button class="btn" type="submit">Send booking request</button>
        </form>
    <?php endif; ?>
</section>
<?php include 'includes/footer.php'; ?>
