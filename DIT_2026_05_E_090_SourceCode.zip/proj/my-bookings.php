<?php
require 'config.php';
require_login();
$me = current_user();
$stmt = $pdo->prepare("SELECT b.*, a.name FROM bookings b JOIN accommodations a ON a.id = b.accommodation_id WHERE b.user_id = ? ORDER BY b.created_at DESC");
$stmt->execute([$me['id']]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
$title = 'My Bookings';
include 'includes/header.php';
?>
<section class="section">
    <h1>My bookings</h1>
    <?php if (!$rows): ?><p>You have not sent any booking requests yet. <a href="find.php">Find accommodation</a></p>
    <?php else: ?>
    <div class="table-wrap"><table>
        <thead><tr><th scope="col">Accommodation</th><th scope="col">Move-in date</th><th scope="col">Phone</th><th scope="col">Sent on</th></tr></thead>
        <tbody><?php foreach ($rows as $r): ?>
            <tr><td><?= e($r['name']) ?></td><td><?= e($r['move_in_date']) ?></td><td><?= e($r['phone']) ?></td><td><?= e(substr($r['created_at'], 0, 10)) ?></td></tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
</section>
<?php include 'includes/footer.php'; ?>
