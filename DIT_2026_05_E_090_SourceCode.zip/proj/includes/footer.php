</main>
<footer><p>© 2026 Student Accommodation Finder. All rights reserved.</p></footer>
<script src="js/main.js"></script>
</body>
</html>
