<?php /* One accommodation card. Expects $a = a row from ACC_SQL. */ $imgs = acc_images($a['id']); ?>
<article class="card"
    data-name="<?= e(strtolower($a['name'] . ' ' . $a['location'])) ?>"
    data-university="<?= e($a['university']) ?>"
    data-location="<?= e($a['location']) ?>"
    data-price="<?= (int)$a['price'] ?>"
    data-room="<?= e($a['room_type']) ?>"
    data-gender="<?= e($a['gender']) ?>"
    data-facilities="<?= e(strtolower($a['facilities'])) ?>"
    data-rating="<?= (float)$a['avg_rating'] ?>"
    data-distance="<?= (float)$a['distance_km'] ?>"
    data-available="<?= (int)$a['rooms_available'] ?>">
    <img src="<?= e($imgs[0]) ?>" alt="<?= e($a['name']) ?> student accommodation">
    <div class="card-body">
        <h3><?= e($a['name']) ?></h3>
        <p><strong>Location:</strong> <?= e($a['location']) ?> (<?= e($a['distance_km']) ?> km from university)</p>
        <p><strong>Price:</strong> Rs. <?= number_format($a['price']) ?> per month</p>
        <p><strong>Room type:</strong> <?= ucfirst(e($a['room_type'])) ?> room · <?= e(gender_label($a['gender'])) ?></p>
        <p><strong>Rating:</strong> <?= e(rating_text($a['avg_rating'], $a['review_count'])) ?></p>
        <p><?= $a['rooms_available'] > 0 ? '<span class="tag ok">Available</span>' : '<span class="tag bad">Full</span>' ?></p>
        <a class="btn" href="details.php?id=<?= (int)$a['id'] ?>">View details<span class="sr"> of <?= e($a['name']) ?></span></a>
    </div>
</article>
