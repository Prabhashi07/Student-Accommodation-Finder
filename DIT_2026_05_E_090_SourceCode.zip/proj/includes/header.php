<?php $page = basename($_SERVER['PHP_SELF']); $me = current_user(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title ?? 'Student Accommodation Finder') ?> | Student Accommodation Finder</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<a class="skip" href="#main">Skip to main content</a>
<nav>
    <a class="logo" href="index.php">Student Accommodation Finder</a>
    <button id="menu-toggle" aria-expanded="false" aria-controls="nav-links">Menu</button>
    <div class="nav-links" id="nav-links">
        <a href="index.php" <?= $page=='index.php' ? 'aria-current="page"' : '' ?>>Home</a>
        <a href="find.php" <?= $page=='find.php' ? 'aria-current="page"' : '' ?>>Find Accommodation</a>
        <a href="how-it-works.php" <?= $page=='how-it-works.php' ? 'aria-current="page"' : '' ?>>How It Works</a>
        <?php if ($me): ?>
            <a href="my-bookings.php" <?= $page=='my-bookings.php' ? 'aria-current="page"' : '' ?>>My Bookings</a>
            <a href="logout.php">Logout (<?= e($me['name']) ?>)</a>
        <?php else: ?>
            <a href="login.php" <?= $page=='login.php' ? 'aria-current="page"' : '' ?>>Login</a>
            <a href="register.php" <?= $page=='register.php' ? 'aria-current="page"' : '' ?>>Register</a>
        <?php endif; ?>
    </div>
</nav>
<main id="main">
